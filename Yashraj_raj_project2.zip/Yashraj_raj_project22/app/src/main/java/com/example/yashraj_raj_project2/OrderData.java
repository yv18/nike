package com.example.yashraj_raj_project2;

public class OrderData {
    private String product_Name;
    private String product_Price;
    private String product_Image;
    private String quantity;
    private String size;

    private  String OrderDate;



    public String getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(String orderDate) {
        OrderDate = orderDate;
    }




    public String getTot() {
        return tot;
    }

    public void setTot(String tot) {
        this.tot = tot;
    }

    public OrderData(String tot) {
        this.tot = tot;
    }

    private String tot;

    public OrderData() {

    }

    public OrderData(String product_Name, String product_Price,String OrderDate, String product_Image, String quantity, String size) {
        this.product_Name = product_Name;
        this.product_Price = product_Price;
        this.product_Image = product_Image;
        this.quantity = quantity;
        this.size = size;
        this.OrderDate = OrderDate;
    }

    public String getProduct_Name() {
        return product_Name;
    }

    public void setProduct_Name(String product_Name) {
        this.product_Name = product_Name;
    }

    public String getProduct_Price() {
        return product_Price;
    }

    public void setProduct_Price(String product_Price) {
        this.product_Price = product_Price;
    }

    public String getProduct_Image() {
        return product_Image;
    }

    public void setProduct_Image(String product_Image) {
        this.product_Image = product_Image;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

}

