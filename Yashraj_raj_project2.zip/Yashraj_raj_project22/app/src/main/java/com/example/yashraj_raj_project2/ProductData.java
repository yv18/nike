package com.example.yashraj_raj_project2;

import android.os.Parcel;
import android.os.Parcelable;

public class ProductData implements Parcelable {


    String Product_Name, Product_Description, Product_Price, Product_Image;
    ProductData() {

    }
    public ProductData(String product_Name, String product_Description, String product_Price, String product_Image) {
        Product_Name = product_Name;
        Product_Description = product_Description;
        Product_Price = product_Price;
        Product_Image = product_Image;
    }
    public String getProduct_Name() {
        return Product_Name;
    }

    public void setProduct_Name(String product_Name) {
        Product_Name = product_Name;
    }

    public String getProduct_Description() {
        return Product_Description;
    }

    public void setProduct_Description(String product_Description) {
        Product_Description = product_Description;
    }

    public String getProduct_Price() {
        return Product_Price;
    }

    public void setProduct_Price(String product_Price) {
        Product_Price = product_Price;
    }

    public String getProduct_Image() {
        return Product_Image;
    }

    public void setProduct_Image(String product_Image) {
        Product_Image = product_Image;
    }

    protected ProductData(Parcel in) {
        Product_Name = in.readString();
        Product_Description = in.readString();
        Product_Price = in.readString();
        Product_Image = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(Product_Name);
        dest.writeString(Product_Description);
        dest.writeString(Product_Price);
        dest.writeString(Product_Image);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ProductData> CREATOR = new Creator<ProductData>() {
        @Override
        public ProductData createFromParcel(Parcel in) {
            return new ProductData(in);
        }

        @Override
        public ProductData[] newArray(int size) {
            return new ProductData[size];
        }
    };
}
