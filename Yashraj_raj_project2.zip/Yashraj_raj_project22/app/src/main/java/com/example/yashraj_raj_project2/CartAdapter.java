package com.example.yashraj_raj_project2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.Firebase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {
    private List<CartData> productList;
    private Context context;
    private TextView CartTotal;
    private int total = 0;
    FirebaseDatabase CartRef;

    public interface QuantityUpdateListener {
        void onQuantityUpdated(int position, int newQuantity);
    }

    public int getUpdatedQuantity(int position) {
        if (position < productList.size()) {
            return Integer.parseInt(productList.get(position).getQuantity());
        }
        return 0;
    }

    private QuantityUpdateListener quantityUpdateListener;

    public CartAdapter(Context context,List<CartData> productList,TextView CartTotal,QuantityUpdateListener listener) {
        this.productList = productList;
        this.context = context;
        this.CartTotal = CartTotal;
        this.quantityUpdateListener = listener;
        updatetotal();
    }

    public int getTotal() {
        return updatetotal();
    }

    private int updatetotal() {
        total = calculateTotalAmount();
        String formattedTotal = String.valueOf(total);
        CartTotal.setText("Total $" + formattedTotal);
        return total;
    }
    private int calculateTotalAmount() {
        int amount = 0;
        for (CartData currentItem : productList) {
            int price = Integer.parseInt(currentItem.getProduct_Price());
            int qnt = Integer.parseInt(currentItem.getQuantity());
            amount += price * qnt;
        }
        return amount;
    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
         View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_list, parent, false);
         return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder,final int position) {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();
        String usermail = encodeEmail(user.getEmail());
        final int itemPosition = position;
        CartData product = productList.get(position);
        holder.productNameTextView.setText(product.getProduct_Name());
        holder.productPriceTextView.setText("Price $" + product.getProduct_Price());
        holder.O_Qnt.setText(product.getQuantity());
        holder.totAmn.setText(product.getProduct_Price());
        holder.Size.setText("Size "+product.getSize());
        Glide.with(holder.Image.getContext())
                .load(product.getProduct_Image())
                .placeholder(com.firebase.ui.database.R.drawable.common_google_signin_btn_icon_dark)
                .error(com.google.firebase.database.R.drawable.common_google_signin_btn_icon_dark_normal)
                .into(holder.Image);

        updatetotal();

        holder.btn_remove.setOnClickListener(v -> {
            productList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, productList.size());
            updatetotal();
            Toast.makeText(context, "Item removed from cart", Toast.LENGTH_SHORT).show();
        });

        holder.btnPlus.setOnClickListener(v -> {
            int quantity = Integer.parseInt(holder.O_Qnt.getText().toString());
            if (quantity < 7) {
                quantity++;
                product.setQuantity(String.valueOf(quantity));
                holder.O_Qnt.setText(String.valueOf(quantity));
                updatetotal();
                if (quantityUpdateListener != null) {
                    quantityUpdateListener.onQuantityUpdated(position, quantity); // Notify the listener about the quantity change
                }
            } else {
                Toast.makeText(context, "You Can Only Add 7 Product at Once", Toast.LENGTH_SHORT).show();
            }
        });

        holder.btnMinus.setOnClickListener(v -> {
            int quantity = Integer.parseInt(holder.O_Qnt.getText().toString());
            if (quantity > 1) {
                quantity--;
                product.setQuantity(String.valueOf(quantity));
                holder.O_Qnt.setText(String.valueOf(quantity));
                updatetotal();
                if (quantityUpdateListener != null) {
                    quantityUpdateListener.onQuantityUpdated(position, quantity); // Notify the listener about the quantity change
                }
            } else {
                Toast.makeText(context, "Minimum limit is 1", Toast.LENGTH_SHORT).show();
            }
        });






    }




    private String encodeEmail(String email) {
        return email.replace(".", ",");
    }


    @Override
    public int getItemCount() {
        return productList.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView productNameTextView;
        TextView productPriceTextView;
        ImageView Image;
        TextView O_Qnt,totAmn,Size;


        Button btnPlus,btnMinus,btn_remove;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            productNameTextView = itemView.findViewById(R.id.C_Name);
            productPriceTextView = itemView.findViewById(R.id.C_Price);
            O_Qnt = itemView.findViewById(R.id.C_Qnt);
            totAmn = itemView.findViewById(R.id.C_tot);
            Image = itemView.findViewById(R.id.C_Image);
            Size = itemView.findViewById(R.id.C_Size);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btn_remove= itemView.findViewById(R.id.btn_remove);
        }

        public void bind(CartData product) {

        }
    }
}
