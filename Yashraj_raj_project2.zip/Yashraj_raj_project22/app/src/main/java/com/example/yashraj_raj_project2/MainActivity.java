package com.example.yashraj_raj_project2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    TextView register;
    EditText loginUsername, loginPassword;
    Button loginButton;
    FirebaseAuth mAuth;

    @Override
    public void onStart() {
        super.onStart();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            Intent home = new Intent(getApplicationContext(), desk.class);
            startActivity(home);
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        loginUsername = findViewById(R.id.signupUsername);
        loginPassword = findViewById(R.id.signupPassword);
        loginButton = findViewById(R.id.loginButton);
        register = findViewById(R.id.register);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!validateUsername() | !validatePassword()) {
                } else {
                    String email = String.valueOf(loginUsername.getText());
                    String password = String.valueOf(loginPassword.getText());
                    mAuth.signInWithEmailAndPassword(email, password)
                            .addOnCompleteListener( new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(MainActivity.this, "Login successful.", Toast.LENGTH_SHORT).show();
                                        Intent home = new Intent(getApplicationContext(), desk.class);
                                        startActivity(home);
                                        finish();
                                    } else {
                                        Toast.makeText(MainActivity.this, "Enter Valid Email and Password", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent register = new Intent(MainActivity.this, register.class);
                startActivity(register);
            }
        });
    }

    public boolean validateUsername() {
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        String val = loginUsername.getText().toString().trim();

        if (val.isEmpty() || !val.matches(emailPattern)) {
            loginUsername.setError("Please enter a valid email");
            return false;
        } else {
            loginUsername.setError(null);
            return true;
        }
    }

    public boolean validatePassword() {
        String val = loginPassword.getText().toString().trim();
        String passwordPattern = "^(?=.*[a-zA-Z]{3})(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?])(?=.*\\d{2})[a-zA-Z\\d!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]{6,}$";

        if (val.isEmpty() || !val.matches(passwordPattern)) {
            loginPassword.setError("Password must be like XyZ@23");
            return false;
        } else {
            loginPassword.setError(null);
            return true;
        }
    }

}