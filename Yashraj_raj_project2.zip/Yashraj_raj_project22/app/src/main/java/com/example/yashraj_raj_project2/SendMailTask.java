package com.example.yashraj_raj_project2;

import android.os.AsyncTask;
import android.util.Log;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMailTask extends AsyncTask<Void, Void, Void> {
    private final String username;
    private final String password;
    private final String recipientEmail;
    private final String subject;
    private final String messageBody;

    public SendMailTask(String username, String password, String recipientEmail, String subject, String messageBody) {
        this.username = username;
        this.password = password;
        this.recipientEmail = recipientEmail;
        this.subject = subject;
        this.messageBody = messageBody;
    }

    @Override
    protected Void doInBackground(Void... voids) {

        try {
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.ssl.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com"); // Replace with your email provider's SMTP server
            props.put("mail.smtp.port", "465"); // Replace with the appropriate port

            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("ryashraj8218@gmail.com", "tdij bgpf vrxl alue");
                }
            });

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject(subject);
            message.setText(messageBody);

            Transport.send(message);

            Log.i("SendMailTask", "Email sent successfully.");

        } catch (MessagingException e) {
            Log.e("SendMailTask", "Error sending email.", e);
        }

        return null;
    }
}
