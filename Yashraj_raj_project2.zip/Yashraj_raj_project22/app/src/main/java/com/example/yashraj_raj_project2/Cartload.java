package com.example.yashraj_raj_project2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Cartload extends AppCompatActivity implements CartAdapter.QuantityUpdateListener {


    RecyclerView recyclerView;
    CartAdapter cartAdapter;
    TextView CartTotal;
    Button btn_Checkout,Backbtn;

    List<CartData> productList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addtocart);
        recyclerView = findViewById(R.id.cartView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        btn_Checkout = findViewById(R.id.btn_Checkout);
        Backbtn = findViewById(R.id.Backbtn);
        CartTotal = findViewById(R.id.CartTotal);



        fetchProductsForCurrentUser();
        cartAdapter = new CartAdapter(this, productList,CartTotal,this);
        int total= cartAdapter.getItemCount();
        CartTotal.setText("Total $" + String.valueOf(total));

        recyclerView.setAdapter(cartAdapter);
        int total1 = cartAdapter.getTotal();
        String formattedTotal = String.valueOf(total1);
        CartTotal.setText(formattedTotal);


        Backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(Cartload.this,desk.class);
                startActivity(home);
                finish();
            }
        });


        btn_Checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < productList.size(); i++) {
                    CartData cartItem = productList.get(i);
                    int updatedQuantity = cartAdapter.getUpdatedQuantity(i);
                    cartItem.setQuantity(String.valueOf(updatedQuantity));
                    productList.set(i, cartItem);
                }
                String Cattot = CartTotal.getText().toString();
                Intent intent = new Intent(Cartload.this, Checkout.class);
                intent.putExtra("PRODUCT_LIST", (Serializable) productList);
                intent.putExtra("total",Cattot);
                startActivity(intent);
            }
        });
    }

    private void fetchProductsForCurrentUser() {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            String userEmail = encodeEmail(user.getEmail());
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference userCartRef = database.getReference("User_Cart").child(userEmail);

            userCartRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    productList.clear();
                    for (DataSnapshot productSnapshot : dataSnapshot.getChildren()) {
                        CartData product = productSnapshot.getValue(CartData.class);
                        if (product != null) {
                            productList.add(product);
                        }
                    }
                    cartAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(Cartload.this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
                }
            });
        }

    }

    public void onQuantityUpdated(int position, int newQuantity) {

    }
    private String encodeEmail(String email) {
        return email.replace(".", ",");
    }

}