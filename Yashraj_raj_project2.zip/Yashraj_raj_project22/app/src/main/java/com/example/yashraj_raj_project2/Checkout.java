package com.example.yashraj_raj_project2;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Checkout extends AppCompatActivity {

   TextView totAmount,tottax,Homebtn,textView16;
   Button btn_Pay;

    private String USERNAME = "ryashraj8218@gmail.com";
    private String PASSWORD = "Raj@2329";
    private  String TO_EMAIL;
    private  String SUBJECT;
    private  String MESSAGE_BODY;

   List<CartData> productList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        btn_Pay = findViewById(R.id.btnPay);
        totAmount = findViewById(R.id.totAmount);
        tottax = findViewById(R.id.tottax);
        Homebtn = findViewById(R.id.Homebtn);
        textView16 = findViewById(R.id.textView16);

        EditText custNameEditText = findViewById(R.id.Cust_Name);
        EditText custAddressEditText = findViewById(R.id.Cust_Address);
        EditText custNumberEditText = findViewById(R.id.Cust_Number);
        EditText custPostalEditText = findViewById(R.id.Cust_Postalcode);
        EditText custCardEditText = findViewById(R.id.Cust_Cardnumber);
        EditText custCVVEditText = findViewById(R.id.Cust_CardCVV);
        EditText custExpDateEditText =findViewById(R.id.Card_ExpDate);
        EditText custCity =findViewById(R.id.Cust_City);
        EditText custProvince =findViewById(R.id.Cust_Province);
        EditText CustcardName = findViewById(R.id.editTextText);

        Homebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(getApplicationContext(), Cartload.class);
                startActivity(home);
                finish();
            }
        });

        textView16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(getApplicationContext(), desk.class);
                startActivity(home);
                finish();
            }
        });

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("PRODUCT_LIST")) {
            List<CartData> productList = (List<CartData>) intent.getSerializableExtra("PRODUCT_LIST");
            String total = intent.getStringExtra("total");
            totAmount.setText(total);
            double totalAmount = 0;
            for (CartData product : productList) {
                String productPrice = product.getProduct_Price();
                String qnt = product.getQuantity();

                double amount = Double.parseDouble(productPrice);
                int quantity = Integer.parseInt(qnt);
                double total1 = amount * quantity;
                double taxRate = 0.13;
                double taxAmount = total1 * taxRate;
                totalAmount += total1 + taxAmount;
            }
            String totalWithTaxText = String.format("Total with tax $%.2f", totalAmount);
            tottax.setText(totalWithTaxText);
        }


        btn_Pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth auth = FirebaseAuth.getInstance();
                FirebaseUser user = auth.getCurrentUser();
                if (user != null) {
                    String userEmail = encodeEmail(user.getEmail()); // Encode email

                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference userOrdersRef = database.getReference("Orders").child(userEmail);

                    Intent intent = getIntent();
                    if (intent != null && intent.hasExtra("PRODUCT_LIST")) {
                        List<CartData> productList = (List<CartData>) intent.getSerializableExtra("PRODUCT_LIST");
                        String costName = custNameEditText.getText().toString().trim();
                        String costAddress = custAddressEditText.getText().toString().trim();
                        String cost_City = custCity.getText().toString().trim();
                        String costProvince_ = custProvince.getText().toString().trim();
                        String costNumber = (custNumberEditText.getText().toString().trim());
                        String costPostal = custPostalEditText.getText().toString().trim();
                        String costCard = (custCardEditText.getText().toString().trim());
                        String costCVV = (custCVVEditText.getText().toString());
                        String costExpDate = custExpDateEditText.getText().toString();
                        String cardName = CustcardName.getText().toString().trim();

                        if (productList != null && isValidName(costName) && isValidCardName(cardName) && isValidAddress(costAddress) && isValidAddress(costAddress) && isValidPostalCode(costPostal) && isValidCVV(costCVV) && isValidExpDate(costExpDate)) {

                            String currentDate = java.time.LocalDate.now().toString();
                            String totalAmount = totAmount.getText().toString();

                            for (CartData product : productList) {
                                String productImage = product.getProduct_Image();
                                String productName = product.getProduct_Name();
                                String productPrice = product.getProduct_Price();
                                String Price = productPrice;
                                String qnt = product.getQuantity();
                                String size = product.getSize();
                                double taxRate = 0.13;
                                double amount = Double.parseDouble(productPrice);
                                int quantity = Integer.parseInt(qnt.toString());
                                double total = amount * quantity;
                                double taxAmount = total * taxRate;
                                double totalWithTax = total + taxAmount;
                                String totaltax = String.valueOf("Total $" + totalWithTax);


                                Map<String, Object> productDetails = new HashMap<>();
                                productDetails.put("product_Image", productImage);
                                productDetails.put("product_Name", productName);
                                productDetails.put("product_Price", productPrice);
                                productDetails.put("quantity",qnt);
                                productDetails.put("size", size);
                                productDetails.put("tot",totaltax);
                                productDetails.put("orderDate", currentDate);
                                userOrdersRef.child("products").push().setValue(productDetails);
                            }
                            Map<String, Object> orderDetails = new HashMap<>();
                            orderDetails.put("productList",productList);
                            orderDetails.put("custName", costName);
                            orderDetails.put("custNumber", costNumber);
                            orderDetails.put("custAddress", costAddress);
                            orderDetails.put("custCity", cost_City);
                            orderDetails.put("custProvince", costProvince_);
                            orderDetails.put("custPostal", costPostal);
                            orderDetails.put("custCard", costCard);
                            orderDetails.put("totalAmount", totalAmount);

                            userOrdersRef.child("Orders_Details").push().setValue(orderDetails)
                                    .addOnCompleteListener(task -> {
                                        if (task.isSuccessful()) {
                                            TO_EMAIL = user.getEmail();
                                            SUBJECT = "Order Confirmation!";
                                            MESSAGE_BODY = "Thanks a lot for choosing our online store for your recent shoe purchase! \n You have paid " + totalAmount +" Your support means a lot. If you need anything, we're here to help.\n" +
                                                    "\n" +
                                                    "Cheers,\n" +
                                                    "Nike Store";
                                            sendEmail();
                                            Toast.makeText(Checkout.this, "Order placed successfully", Toast.LENGTH_SHORT).show();
                                            deleteAllProductsForCurrentUser();
                                            Intent paymentIntent = new Intent(Checkout.this, Paymentdone.class);
                                            startActivity(paymentIntent);
                                            finish();
                                        } else {
                                            Toast.makeText(Checkout.this, "Failed to place order", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        } else {
                            if (!isValidName(costName)) {
                                Toast.makeText(Checkout.this, "Check Your Name", Toast.LENGTH_SHORT).show();
                                custNameEditText.setError("Please Check Your Name");
                            }
                            if (!isValidPhoneNumber(costNumber)) {
                                custNumberEditText.setError("Please Check Your Number");
                            }

                            if (!isValidCardName(cardName)) {
                                CustcardName.setError("Please make sure Your name written in Capital letters");
                                Toast.makeText(Checkout.this, "Check Your Name", Toast.LENGTH_SHORT).show();
                            }

                            if (!isValidAddress(costAddress)) {
                                custAddressEditText.setError("Please Check Your Address");
                                Toast.makeText(Checkout.this, "Check Your Address", Toast.LENGTH_SHORT).show();
                            }

                            if (!isValidPostalCode(costPostal)) {
                                custPostalEditText.setError("Please Check Your Postal Code");
                            }
                            if (!isValidCVV(costCVV)) {
                                custCVVEditText.setError("Please Check Your CVV");
                            }

                            if (!isValidExpDate(costExpDate)) {
                                custExpDateEditText.setError("Please Check Your Expiry/Date");
                            }

                            if (!isValidCity(cost_City)) {
                                custCity.setError("Please Check Your City Name");
                            }

                            if (!isValidProvince(costProvince_)) {
                                custProvince.setError("Please Check Your Province Name");
                            }

                            if (!isValidCardNumber(costCard)) {
                                custCardEditText.setError("Please Check Your Card Number It must be 16 digits");
                            }

                        }
                    }
                }
            }
        });




    }

    // Postal code validation
    private boolean isValidPostalCode(String costPostal) {
        String regex ="[A-Za-z]\\d[A-Za-z] ?\\d[A-Za-z]\\d";
        return costPostal.matches(regex);
    }

    // Address validation
    private boolean isValidAddress(String costAddress) {
        String regex = "^[0-9]{3}\\s[A-Z][a-z]+\\s[A-Z][a-z]+$";
        return costAddress.matches(regex);
    }

    private boolean isValidCVV(String costCVV) {
        String cvvString = String.valueOf(costCVV);
        return cvvString.matches("\\d{3}");
    }


    private boolean isValidExpDate(String costExpDate) {
        //Card validation for MM/YY format
        return costExpDate.matches("(0[1-9]|1[0-2])/(2[4-9]|3[0-3])|12/23$");
    }



    // Name validation
    private boolean isValidName(String costName) {
        String regex = "^[A-Z][a-z]+\\s[A-Z][a-z]+$";
        return costName.matches(regex);
    }

    // Phone Number validation
    private boolean isValidPhoneNumber(String costNumber) {
        return String.valueOf(costNumber).length() == 10;
    }

    // Card number validation
    private boolean isValidCardNumber(String costCard) {
        String regex1 = "^4[0-9]{12}(?:[0-9]{3})?$";
        return costCard.matches(regex1);
    }

    private boolean isValidCardName(String cardName) {
        String regex = "^([A-Z]+[,.]?[ ]?|[A-Z]+['-]?)+$";
        return cardName.matches(regex);
    }



    //    province validation
    private boolean isValidProvince(String costProvince_) {
        String provincePattern = "^[a-zA-Z][a-zA-Z\\s-]+[a-zA-Z]$";
        return costProvince_.matches(provincePattern);
    }

    //City
    private boolean isValidCity(String cost_City) {
        String cityPattern = "^[a-zA-Z][a-zA-Z\\s-]+[a-zA-Z]$";
        return cost_City.matches(cityPattern);
    }

    private String encodeEmail (String email){
        return email.replace(".", ",");
    }

    private void deleteAllProductsForCurrentUser() {

        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            String userEmail = encodeEmail(user.getEmail());

            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference userCartRef = database.getReference("User_Cart").child(userEmail);

            userCartRef.removeValue()
                    .addOnSuccessListener(aVoid -> {
                        productList.clear();
                        Toast.makeText(Checkout.this, "Thank you for purchasing", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {

                        Toast.makeText(Checkout.this, "Failed to proceed", Toast.LENGTH_SHORT).show();
                    });
        }
    }
    private void sendEmail() {
        SendMailTask sendMailTask = new SendMailTask(USERNAME, PASSWORD, TO_EMAIL, SUBJECT, MESSAGE_BODY);
        sendMailTask.execute();
    }
}