package com.example.yashraj_raj_project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class product extends AppCompatActivity {
 TextView Price,Name,Description,txtEmail,CartSize;
 ImageView image;

    FirebaseAuth auth;
    FirebaseUser user;

 Button btnBack,btnCheckout,btnCart;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference imagesRef = database.getReference().child("products").child("p");

    CheckBox Sizetxt1,Sizetxt2,Sizetxt3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        Price = findViewById(R.id.Price);
        Name = findViewById(R.id.Name);
        Description = findViewById(R.id.Description);
        image = findViewById(R.id.image);
        btnBack = findViewById(R.id.btnBack);
        txtEmail = findViewById(R.id.txtEmail);
        btnCheckout = findViewById(R.id.btnCheckout);
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        btnCart = findViewById(R.id.btnCart);
        Sizetxt1 = findViewById(R.id.Sizetxt1);
        Sizetxt2 = findViewById(R.id.Sizetxt2);
        Sizetxt3 = findViewById(R.id.Sizetxt3);
        CartSize = findViewById(R.id.CartSize);
        CartSize.setText("Not Selected");

        if(user == null) {
            Intent log = new Intent(product.this, MainActivity.class);
            startActivity(log);
            finish();
        }
        else {
            txtEmail.setText(user.getEmail());
        }


        Intent intent = getIntent();
        if (intent != null) {
            ProductData product = intent.getParcelableExtra("PRODUCT_DATA");

            Name.setText(product.getProduct_Name());
            Price.setText("$"+product.getProduct_Price());
            Description.setText(product.getProduct_Description());
            Glide.with(this)
                    .load(product.getProduct_Image())
                    .into(image);

            btnCheckout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent cartIntent = new Intent(getApplicationContext(), Orderplace.class);
                    cartIntent.putExtra("PRODUCT_DATA", product);
                    startActivity(cartIntent);
                    finish();
                }
            });
        }


        btnCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth auth = FirebaseAuth.getInstance();
                FirebaseUser user = auth.getCurrentUser();
                boolean isChecked = Sizetxt1.isChecked() || Sizetxt2.isChecked() || Sizetxt3.isChecked();
                if (!isChecked) {
                    Toast.makeText(product.this, "Please select a size.", Toast.LENGTH_SHORT).show();
                } else {
                    if (user != null) {
                        String userEmail = encodeEmail(user.getEmail()); // Encode email
                        String userCartSize = CartSize.getText().toString();
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference userCartRef = database.getReference("User_Cart").child(userEmail);

                        if (intent != null) {
                            ProductData product = intent.getParcelableExtra("PRODUCT_DATA");

                            if (product != null) {
                                Map<String, Object> productDetails = new HashMap<>();
                                productDetails.put("product_Name", product.getProduct_Name());
                                productDetails.put("product_Price", product.getProduct_Price());
                                productDetails.put("product_Image", product.getProduct_Image());
                                productDetails.put("quantity", "1");
                                productDetails.put("size", userCartSize);
                                userCartRef.push().setValue(productDetails)
                                        .addOnCompleteListener(task -> {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(product.this, "You Item " + product.Product_Name + " has been Added to the cart", Toast.LENGTH_SHORT).show();

                                            } else {
                                                Toast.makeText(product.this, "Connection Error", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                            }
                        }
                    }

                }

                }
        });



        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back = new Intent(getApplicationContext(), desk.class);
                startActivity(back);
                finish();
            }
        });

        Sizetxt1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Sizetxt2.setChecked(false);
                    Sizetxt3.setChecked(false);
                    String checkBoxText = Sizetxt1.getText().toString();
                    CartSize.setText(checkBoxText);
                } else {
                    CartSize.setText("Not Selected");
                }
            }
        });

        Sizetxt2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Sizetxt1.setChecked(false);
                    Sizetxt3.setChecked(false);
                    String checkBoxText = Sizetxt2.getText().toString();
                    CartSize.setText(checkBoxText);
                } else {
                    CartSize.setText("Not Selected");
                }
            }
        });

        Sizetxt3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Sizetxt1.setChecked(false);
                    Sizetxt2.setChecked(false);
                    String checkBoxText = Sizetxt3.getText().toString();
                    CartSize.setText(checkBoxText);
                } else {
                    CartSize.setText("Not Selected");
                }
            }
        });
        
    }

    private String encodeEmail(String email) {
        return email.replace(".", ",");
    }
}