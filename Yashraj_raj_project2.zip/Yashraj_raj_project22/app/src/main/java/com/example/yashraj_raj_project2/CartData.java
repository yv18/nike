package com.example.yashraj_raj_project2;

import java.io.Serializable;

public class CartData implements Serializable {

    public CartData() {

    }
    public String getProduct_Name() {
        return product_Name;
    }

    public void setProduct_Name(String product_Name) {
        this.product_Name = product_Name;
    }

    public String getProduct_Price() {
        return product_Price;
    }

    public void setProduct_Price(String product_Price) {
        this.product_Price = product_Price;
    }

    public String getProduct_Image() {
        return product_Image;
    }

    public void setProduct_Image(String product_Image) {
        this.product_Image = product_Image;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public CartData(String product_Name, String product_Price, String product_Image, String quantity, String size, String total) {
        this.product_Name = product_Name;
        this.product_Price = product_Price;
        this.product_Image = product_Image;
        this.quantity = quantity;
        this.size = size;
        this.total = total;
    }

    private boolean isSelected;

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
    private String product_Name;
    private String product_Price;
    private String product_Image;
    private String quantity;
    private String size;
    private String total;

}
