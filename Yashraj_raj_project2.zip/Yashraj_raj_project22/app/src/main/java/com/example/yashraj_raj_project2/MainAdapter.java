package com.example.yashraj_raj_project2;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class MainAdapter extends FirebaseRecyclerAdapter<ProductData,MainAdapter.myViewHolder> {
    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public MainAdapter(@NonNull FirebaseRecyclerOptions<ProductData> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myViewHolder holder, int position, @NonNull ProductData model) {

        holder.name.setText(model.getProduct_Name());
        holder.price.setText("$"+model.getProduct_Price());
//        holder.description.setText(model.getProduct_Description());

        Glide.with(holder.image.getContext())
                .load(model.getProduct_Image())
                .placeholder(com.firebase.ui.database.R.drawable.common_google_signin_btn_icon_dark)
                .error(com.google.firebase.database.R.drawable.common_google_signin_btn_icon_dark_normal)
                .into(holder.image);

        final String productName = model.getProduct_Name();
        final String productPrice = model.getProduct_Price();
        final String productDescription = model.getProduct_Description();
        final String productImage = model.getProduct_Image();

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), product.class);
                intent.putExtra("PRODUCT_DATA", model);
                intent.putExtra("PRODUCT_NAME", productName);
                intent.putExtra("PRODUCT_PRICE", productPrice);
                intent.putExtra("PRODUCT_DESCRIPTION", productDescription);
                intent.putExtra("PRODUCT_IMAGE", productImage);
                v.getContext().startActivity(intent);
            }
        });

    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent, false);
        return new myViewHolder(view);
    }

    class myViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView name,price,description;

        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            image =(ImageView)itemView.findViewById(R.id.image);
            name =(TextView) itemView.findViewById(R.id.name);
            price =(TextView) itemView.findViewById(R.id.price);
            description =(TextView) itemView.findViewById(R.id.description);

        }
    }
}
