package com.example.yashraj_raj_project2;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class Orderplace extends AppCompatActivity {
    CheckBox checkBox1,checkBox2,checkBox3;
    TextView txtName,totAmount1,backbutoon;
    FirebaseAuth auth;
    FirebaseUser user;
    TextView quantityTextView;
    private int quantity = 1;
    Button increaseButton,decreaseButton,btnPayO;
    TextView txtSize;

    TextView cartName, cartPrice,hide;
    ImageView cartImage;

    private String USERNAME = "ryashraj8218@gmail.com";
    private String PASSWORD = "Raj@2329";
    private  String TO_EMAIL;
    private  String SUBJECT;
    private  String MESSAGE_BODY;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        quantityTextView = findViewById(R.id.quantityTextView);
         increaseButton = findViewById(R.id.increaseButton);
         decreaseButton = findViewById(R.id.decreaseButton);
        checkBox1 = findViewById(R.id.checkBox1);
        checkBox2 = findViewById(R.id.checkBox2);
        checkBox3 = findViewById(R.id.checkBox3);
        txtName = findViewById(R.id.txtName);
        txtSize = findViewById(R.id.txtSize);
        totAmount1 = findViewById(R.id.totAmount);
        backbutoon = findViewById(R.id.backbutoon);
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        btnPayO = findViewById(R.id.btnPayO);
        hide = findViewById(R.id.hide);

        cartPrice = findViewById(R.id.P_Price);
        cartName = findViewById(R.id.P_Name);
        cartImage = findViewById(R.id.img);
        EditText custNameEditText = findViewById(R.id.Cust_Name);
        EditText custAddressEditText = findViewById(R.id.Cust_Address);
        EditText custNumberEditText = findViewById(R.id.Cust_Number);
        EditText custPostalEditText = findViewById(R.id.Cust_Postalcode);
        EditText custCardEditText = findViewById(R.id.Cust_Cardnumber);
        EditText custCVVEditText = findViewById(R.id.Cust_CardCVV);
        EditText custExpDateEditText =findViewById(R.id.Card_ExpDate);
        EditText custCity =findViewById(R.id.Cust_City);
        EditText custProvince =findViewById(R.id.Cust_Province);
        EditText CustcardName1 = findViewById(R.id.editTextText1);
//        custNumberEditText.setText("0"); //defualt
//        custCardEditText.setText("0");//defualt
//        custCVVEditText.setText("0");//defualt

        backbutoon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(getApplicationContext(), desk.class);
                startActivity(home);
                finish();
            }
        });


        Intent intent = getIntent();
        if (intent != null) {
            ProductData product = intent.getParcelableExtra("PRODUCT_DATA");
            // Set values to the views in the cart
            if (product != null) {
                cartPrice.setText("$" + product.getProduct_Price());
                cartName.setText(product.getProduct_Name());
                hide.setText(product.getProduct_Price());

                Glide.with(this)
                        .load(product.getProduct_Image())
                        .into(cartImage);

                double price = Double.parseDouble(hide.getText().toString());
                double totalAmount = price * quantity;
                double tax = 0.13 * totalAmount;
                double totalAmountWithTax = totalAmount + tax;
                totAmount1.setText("Total $" + totalAmountWithTax);
            }
        }




        btnPayO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth auth = FirebaseAuth.getInstance();
                FirebaseUser user = auth.getCurrentUser();

                boolean isChecked = checkBox1.isChecked() || checkBox2.isChecked() || checkBox3.isChecked();

                if (!isChecked) {
                    Toast.makeText(Orderplace.this, "Please select a size.", Toast.LENGTH_SHORT).show();
                } else {
                    if (user != null) {
                        String userEmail = encodeEmail(user.getEmail()); // Encode email

                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference userCartRef = database.getReference("Orders").child(userEmail);

                        if (intent != null) {
                            ProductData product = intent.getParcelableExtra("PRODUCT_DATA");
                            String quantity = quantityTextView.getText().toString();
                            String size = txtSize.getText().toString();
                            String tot = totAmount1.getText().toString();
                            String costName = custNameEditText.getText().toString().trim();
                            String costAddress = custAddressEditText.getText().toString().trim();
                            String cost_City = custCity.getText().toString().trim();
                            String costProvince_ = custProvince.getText().toString().trim();
                            String cardName = CustcardName1.getText().toString();

                            String costNumber = (custNumberEditText.getText().toString());
                            String costPostal = custPostalEditText.getText().toString();
                            String costCard = (custCardEditText.getText().toString());
                            String costCVV = (custCVVEditText.getText().toString());
                            String costExpDate = custExpDateEditText.getText().toString();

                            if (product != null && isValidName(costName) && isValidAddress(costAddress) &&
                                    isValidPostalCode(costPostal) &&
                                    isValidCVV(costCVV) && isValidCity(cost_City) && isValidProvince(costProvince_) &&
                                    isValidExpDate(costExpDate)) {


                                String currentDate = java.time.LocalDate.now().toString();
                                Map<String, Object> productDetails = new HashMap<>();
                                productDetails.put("product_Image",product.getProduct_Image());
                                productDetails.put("product_Price",product.getProduct_Price());
                                productDetails.put("product_Name",product.getProduct_Name());
                                productDetails.put("quantity", quantity);
                                productDetails.put("size", size);
                                productDetails.put("tot", tot);
                                // CustomerData
                                productDetails.put("OrderDate", currentDate);
                                productDetails.put("CustName", costName);
                                productDetails.put("CustNumber", costNumber);
                                productDetails.put("CustAddress", costAddress);
                                productDetails.put("CustCity", cost_City);
                                productDetails.put("CustProvince", costProvince_);
                                productDetails.put("CustPostal", costPostal);
                                productDetails.put("CustCard", costCard);

                                userCartRef.child("products").push().setValue(productDetails)
                                        .addOnCompleteListener(task -> {
                                            if (task.isSuccessful()) {
                                                // Proceed to payment page
                                                TO_EMAIL = user.getEmail();
                                                SUBJECT = "Order Confirmation!";
                                                MESSAGE_BODY = "Thanks a lot for choosing our online store for your recent shoe purchase! \nYou have paid " + tot +" Your support means a lot. \nIf you need anything, we're here to help you.\n" +
                                                        "\n" +
                                                        "Have a good day,\n" +
                                                        "Nike Store";
                                                sendEmail();
                                                Toast.makeText(Orderplace.this, "You Order " + product.Product_Name + " has been placed", Toast.LENGTH_SHORT).show();
                                                Intent paymentIntent = new Intent(Orderplace.this, Paymentdone.class);
                                                startActivity(paymentIntent);
                                                finish();
                                            } else {
                                                Toast.makeText(Orderplace.this, "Connection Error", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                            } else {
                                if (!isValidName(costName)) {
                                    Toast.makeText(Orderplace.this, "Check Your Name", Toast.LENGTH_SHORT).show();
                                    custNameEditText.setError("Please Check Your Name");
                                }

                                if (!isValidCardName(cardName)) {
                                    CustcardName1.setError("Please make sure Your name written in Capital letters");
                                }

                                if (!isValidPhoneNumber(costNumber)) {
                                    custNumberEditText.setError("Please Check Your Number");
                                }

                                if (!isValidAddress(costAddress)) {
                                    custAddressEditText.setError("Please Check Your Address");
                                    Toast.makeText(Orderplace.this, "Check Your Address", Toast.LENGTH_SHORT).show();

                                }

                                if (!isValidPostalCode(costPostal)) {
                                    custPostalEditText.setError("Please Check Your Postal Code");
                                }
                                if (!isValidCVV(costCVV)) {
                                    custCVVEditText.setError("Please Check Your CVV");
                                }

                                if (!isValidExpDate(costExpDate)) {
                                    custExpDateEditText.setError("Please Check Your Expiry/Date");
                                }

                                if (!isValidCity(cost_City)) {
                                    custCity.setError("Please Check Your City Name");
                                }

                                if (!isValidProvince(costProvince_)) {
                                    custProvince.setError("Please Check Your Province Name");
                                }

                                if (!isValidCardNumber(costCard)) {
                                    custCardEditText.setError("Please Check Your Card Number It must be 16 digits");
                                }


                            }
                        }
                    }
                }
            }
        });



        if(user == null) {
            Intent log = new Intent(Orderplace.this, MainActivity.class);
            startActivity(log);
            finish();
        }
        else {
            txtName.setText(user.getEmail());
        }

        quantityTextView.setText(String.valueOf(quantity));

        increaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quantity < 7) {
                    // Increase the quantity only if it's less than 7
                    quantity++;
                    // Update the TextView to display the new quantity
                    quantityTextView.setText(String.valueOf(quantity));
                    updateTotalAmount();
                } else {

                    Toast.makeText(Orderplace.this, "You can buy a maximum of 7 shoes at once.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        decreaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ensure the quantity doesn't go below 1
                if (quantity > 1) {
                    // Decrease the quantity
                    quantity--;
                    // Update the TextView to display the new quantity
                    quantityTextView.setText(String.valueOf(quantity));
                    // Update the total amount when decreasing quantity
                    updateTotalAmount();
                } else {
                    Toast.makeText(Orderplace.this, "You can't have less than 1 product", Toast.LENGTH_SHORT).show();
                }
            }
        });




        checkBox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    checkBox2.setChecked(false);
                    checkBox3.setChecked(false);
                    String checkBoxText = checkBox1.getText().toString();
                    txtSize.setText(checkBoxText);
                } else {
                    txtSize.setText("Not Selected");
                }
            }
        });

        checkBox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    checkBox1.setChecked(false);
                    checkBox3.setChecked(false);
                    String checkBoxText = checkBox2.getText().toString();
                    txtSize.setText(checkBoxText);
                } else {
                    txtSize.setText("Not Selected"); // Clear the TextView if CheckBox2 is unchecked
                }
            }
        });

        checkBox3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    checkBox1.setChecked(false);
                    checkBox2.setChecked(false);
                    String checkBoxText = checkBox3.getText().toString();
                    txtSize.setText(checkBoxText);
                } else {
                    txtSize.setText("Not Selected"); // Clear the TextView if CheckBox3 is unchecked
                }
            }
        });


    }
    private void updateTotalAmount() {
            double price = Double.parseDouble(hide.getText().toString());
            double totalAmount = price * quantity;
            double tax = 0.13 * totalAmount;
            double totalAmountWithTax = totalAmount + tax;
            totAmount1.setText("Total $"+ String.valueOf(totalAmountWithTax) + " Including Tax");
    }


    //card name validation
    private boolean isValidCardName(String cardName) {
        String regex = "^([A-Z]+[,.]?[ ]?|[A-Z]+['-]?)+$";
        return cardName.matches(regex);
    }


    // Function to encode email
    private String encodeEmail(String email) {
        return email.replace(".", ",");
    }


    // Postal code validation
    private boolean isValidPostalCode(String costPostal) {
        String regex ="[A-Za-z]\\d[A-Za-z] ?\\d[A-Za-z]\\d";
        return costPostal.matches(regex);
    }

    // Address validation
    private boolean isValidAddress(String costAddress) {
        String regex = "^[0-9]{3}\\s[A-Z][a-z]+\\s[A-Z][a-z]+$";
        return costAddress.matches(regex);
    }

    private boolean isValidCVV(String costCVV) {
            return costCVV.matches("\\d{3}");
    }


    private boolean isValidExpDate(String costExpDate) {
        return costExpDate.matches("(0[1-9]|1[0-2])/(2[4-9]|3[0-3])|12/23$");
    }

    // Name validation
    private boolean isValidName(String costName) {
        String regex = "^[A-Z][a-z]+\\s[A-Z][a-z]+$";
        return costName.matches(regex);
    }


    private boolean isValidCardNumber(String costCard) {
        String regex = "^4[0-9]{12}(?:[0-9]{3})?$";
        return costCard.matches(regex);
    }


    private boolean isValidPhoneNumber(String costNumber) {
        return String.valueOf(costNumber).length() == 10;
    }




//    province validation
    private boolean isValidProvince(String costProvince_) {
        String provincePattern = "^[a-zA-Z][a-zA-Z\\s-]+[a-zA-Z]$";
        return costProvince_.matches(provincePattern);
    }

    //City
    private boolean isValidCity(String cost_City) {
        String cityPattern = "^[a-zA-Z][a-zA-Z\\s-]+[a-zA-Z]$";
        return cost_City.matches(cityPattern);
    }

    private void sendEmail() {
        SendMailTask sendMailTask = new SendMailTask(USERNAME, PASSWORD, TO_EMAIL, SUBJECT, MESSAGE_BODY);
        sendMailTask.execute();
    }

}
