package com.example.yashraj_raj_project2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ProductViewHolder> {

    private List<OrderData> productList;
    private Context context;

    public OrderAdapter(Context context, List<OrderData> productList) {
        this.context = context;
        this.productList = productList;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.order_list, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        OrderData product = productList.get(position);
        holder.productNameTextView.setText(product.getProduct_Name());
        holder.productPriceTextView.setText("Price $" + product.getProduct_Price());
        holder.O_Qnt.setText(product.getQuantity());
        holder.totAmn.setText(product.getTot());
        holder.Size.setText("Size " + product.getSize());
        holder.OrderDate.setText("Order Date " + product.getOrderDate());
        Glide.with(holder.Image.getContext())
                .load(product.getProduct_Image())
                .placeholder(com.firebase.ui.database.R.drawable.common_google_signin_btn_icon_dark)
                .error(com.google.firebase.database.R.drawable.common_google_signin_btn_icon_dark_normal)
                .into(holder.Image);
    }


    @Override
    public int getItemCount() {
        return productList.size();
    }

    public static class ProductViewHolder extends RecyclerView.ViewHolder {
        TextView productNameTextView;
        TextView productPriceTextView;
        ImageView Image;
        TextView O_Qnt,totAmn,Size;
        TextView OrderDate;


        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            productNameTextView = itemView.findViewById(R.id.O_Name);
            productPriceTextView = itemView.findViewById(R.id.O_Price);
            O_Qnt = itemView.findViewById(R.id.O_Qnt);
            totAmn = itemView.findViewById(R.id.total);
            Image = itemView.findViewById(R.id.O_Image);
            Size = itemView.findViewById(R.id.O_Size);
            OrderDate = itemView.findViewById(R.id.OrderDate);
        }
    }
}
