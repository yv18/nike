package com.example.yashraj_raj_project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

public class desk extends AppCompatActivity {
    FirebaseAuth auth;
    FirebaseUser user;
    TextView details,btnCart,btn_Cart;
    RecyclerView recyclerView;
    MainAdapter mainAdapter;
    Button btnLogout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desk);
        details = findViewById(R.id.details);
        btnLogout = findViewById(R.id.btnLogout);
        btnCart = findViewById(R.id.btnCart);
        btn_Cart = findViewById(R.id.btn_Cart);
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        recyclerView = (RecyclerView)findViewById(R.id.rView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));




        FirebaseRecyclerOptions<ProductData> options =
                new FirebaseRecyclerOptions.Builder<ProductData>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("products"), ProductData.class)
                        .build();

        mainAdapter = new MainAdapter(options);
        recyclerView.setAdapter(mainAdapter);

        if(user == null) {
            Intent log = new Intent(desk.this, MainActivity.class);
            startActivity(log);
            finish();
        }
        else {
            details.setText(user.getEmail());
        }


        btn_Cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cart = new Intent(getApplicationContext(), Cartload.class);
                startActivity(cart);
                finish();
            }
        });


//        SignOut
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent log = new Intent(desk.this, MainActivity.class);
                startActivity(log);
                finish();
            }
        });

        btnCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Cart = new Intent(getApplicationContext(),orders.class);
                startActivity(Cart);
                finish();
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        mainAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

}