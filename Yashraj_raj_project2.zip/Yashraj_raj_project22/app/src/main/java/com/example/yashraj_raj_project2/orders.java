package com.example.yashraj_raj_project2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class orders extends AppCompatActivity  {

     RecyclerView recyclerView;
     OrderAdapter orderAdapter;
     List<OrderData> productList = new ArrayList<>();
     TextView totCart;
     Button O_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        recyclerView = findViewById(R.id.OrderView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        orderAdapter = new OrderAdapter(this, productList);
        recyclerView.setAdapter(orderAdapter);
        O_back = findViewById(R.id.O_back);


        O_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back = new Intent(getApplicationContext(),desk.class);
                startActivity(back);
                finish();
            }
        });
        fetchProductsForCurrentUser();
    }



    private void fetchProductsForCurrentUser() {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            String userEmail = encodeEmail(user.getEmail()); // Encode email

            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference userCartRef = database.getReference("Orders").child(userEmail).child("products");

            userCartRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    productList.clear(); // Clear existing list before adding new items
                    for (DataSnapshot productSnapshot : dataSnapshot.getChildren()) {
                        OrderData product = productSnapshot.getValue(OrderData.class);
                        if (product != null) {
                            productList.add(product);
                        }
                    }
                    orderAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(orders.this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
                }
            });
        }

    }








    private String encodeEmail(String email) {
        return email.replace(".", ",");
    }


}