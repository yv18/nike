package com.example.yashraj_raj_project2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class register extends AppCompatActivity {

    FirebaseAuth mAuth;
    EditText signupEmail, signupPassword;

    TextView txtLogin;
    Button signupButton;
    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    public void onStart() {
        super.onStart();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            Intent home = new Intent(getApplicationContext(), desk.class);
            startActivity(home);
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mAuth = FirebaseAuth.getInstance();
        txtLogin = findViewById(R.id.txtLogin);
        signupEmail = findViewById(R.id.signupEmail);
        signupPassword = findViewById(R.id.signupPassword);
        signupButton = findViewById(R.id.signupButton);
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validateUsername() | !validatePassword()) {
                } else {
                String email = String.valueOf(signupEmail.getText());
                String password = String.valueOf(signupPassword.getText());
                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener( new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Toast.makeText(register.this, "Account Created Successfully",
                                            Toast.LENGTH_SHORT).show();
                                    Intent home = new Intent(getApplicationContext(), desk.class);
                                    startActivity(home);
                                    finish();
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(register.this, "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }   }
        });


        txtLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent log = new Intent( getApplicationContext(),MainActivity.class);
                startActivity(log);
                finish();
            }
        });
    }


    public boolean validateUsername() {
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        String val = signupEmail.getText().toString().trim();

        if (val.isEmpty() || !val.matches(emailPattern)) {
            signupEmail.setError("Please enter a valid email");
            return false;
        } else {
            signupEmail.setError(null);
            return true;
        }
    }

    public boolean validatePassword() {
        String val = signupPassword.getText().toString().trim();
        String passwordPattern = "^(?=.*[a-zA-Z]{3})(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?])(?=.*\\d{2})[a-zA-Z\\d!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]{6,}$";

        if (val.isEmpty() || !val.matches(passwordPattern)) {
            signupPassword.setError("Password must be like XyZ@23");
            return false;
        } else {
            signupPassword.setError(null);
            return true;
        }
    }
}